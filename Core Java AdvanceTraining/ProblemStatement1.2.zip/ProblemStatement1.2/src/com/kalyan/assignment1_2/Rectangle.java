package com.kalyan.assignment1_2;

import java.util.Scanner;

class Rectangle {
		
	int length;
	int breadth;
	int area;
	int perimeter;
	
public Rectangle() {
	length=0;
	breadth=0;
}
	
	void input() {
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter Length of Rectangle: ");
		 length=sc.nextInt();
		
		System.out.println("EnterBreadth of Rectangle ");
		 breadth =sc.nextInt();
	
	}
	
	void caluculate() {
		 area= length * breadth;
		 perimeter = 2 * (length + breadth);
			
	}
	
	void display() {
		System.out.println("Area of Rectangle = " + area);
		System.out.println("Peimeter of Rectangle = " + perimeter);
	}
	
	public static void main(String[] args) {
		Rectangle obj1 = new Rectangle();
		obj1.input();
		obj1.caluculate();
		obj1.display();
		System.out.println("___________________________");
		
		Rectangle obj2 = new Rectangle();
		obj2.input();
		obj2.caluculate();
		obj2.display();
		System.out.println("___________________________");
		
		Rectangle obj3 = new Rectangle();
		obj3.input();
		obj3.caluculate();
		obj3.display();
		System.out.println("___________________________");
		
		Rectangle obj4 = new Rectangle();
		obj4.input();
		obj4.caluculate();
		obj4.display();
		System.out.println("___________________________");
		
		Rectangle obj5 = new Rectangle();
		obj5.input();
		obj5.caluculate();
		obj5.display();
		System.out.println("___________________________");
		
	}
}
