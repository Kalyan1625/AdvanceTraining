package com.kalyan.assignment6_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentNames {
	
	public static void main(String[] args) {
		
		ArrayList<String> a1= new ArrayList<String>();
		
	 Scanner sc = new Scanner(System.in);
	 System.out.println("Enter the number of students :");
	 int n =sc.nextInt();
	 
	 System.out.println("Enter the Student names:");
	 
	 for (int i=0; i<n; i++) {
		 a1.add(sc.next());
	 }
	 
	 System.out.println("student list: ");
	 
	 for(String a:a1) {
		 System.out.println("enter the name of the students to be searched:");
		 
		 String st =sc.next();
		 int position=Collections.binarySearch(a1,st);
		 System.out.println("Position of "+st+" is:"+position);
		 
	 }
	}

}
