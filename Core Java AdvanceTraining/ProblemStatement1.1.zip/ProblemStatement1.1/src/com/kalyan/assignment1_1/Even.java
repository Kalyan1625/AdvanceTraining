package com.kalyan.assignment1_1;

import java.util.Scanner;

public class Even {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		//System.out.println("Enter the value of M:");
		//int m=sc.nextInt();
		System.out.println("Enter the value of N:");
		int n=sc.nextInt();
		
		for(int i=0;i<=n;i++) {
			
			if(i%2==0) {
				System.out.println(i);
			}
		}
	}

}
