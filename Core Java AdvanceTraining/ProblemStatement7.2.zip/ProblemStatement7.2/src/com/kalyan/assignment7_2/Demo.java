package com.kalyan.assignment7_2;

class NameNotValidException extends Exception {
	public String validname()
	{
		return ("Name is not valid .. Please Reenter the Name");
	}

}
