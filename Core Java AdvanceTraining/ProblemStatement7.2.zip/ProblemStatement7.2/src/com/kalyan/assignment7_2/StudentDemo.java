package com.kalyan.assignment7_2;

import java.io.BufferedReader;
import java.io.*;

public class StudentDemo {


	public static void main(String[] args) throws Exception {
		
		BufferedReader br =new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter the roll number:");
		int roll=Integer.parseInt(br.readLine());
		System.out.println("\nEnter name:");
		String name=br.readLine();
		System.out.println("\n Enter age:");
		int age=Integer.parseInt(br.readLine());
		System.out.println("\nEnter the course: ");
		String course=br.readLine();
		Student s=new Student(roll,age,name,course);
		s.display();
	}
}
