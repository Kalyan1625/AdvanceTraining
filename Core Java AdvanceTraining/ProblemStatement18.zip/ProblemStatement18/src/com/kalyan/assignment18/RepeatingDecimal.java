package com.kalyan.assignment18;

import java.util.*;

public class RepeatingDecimal {

	public static String caluculateFractions(int num,int de)
	{
		if(num == 0)
			return "0";
		if(de == 0)
			return "";
		
		StringBuilder result= new StringBuilder();
		if((num<0)^(de<0))
			result.append("-");
		num=Math.abs(num);
		de=Math.abs(de);
		
		long quo =num/de;
		long rem=num%de*10;
		
		result.append(String.valueOf(quo));
		if(rem == 0)
			return result.toString();
		
		result.append(".");
		Map<Long,Integer> m = new HashMap<>();
		while(rem!=0) {
			if(m.containsKey(rem)) {
				
				int index = m.get(rem);
				String part1=result.substring(0,index);
				String part2="(" +result.substring(index,result.length()) +")";
				
				return part1+part2;
			}
			
			m.put(rem, result.length());
			quo=rem/de;
			result.append(String.valueOf(quo));
			
			rem = (rem%de)*10;
		}
		return result.toString();
		
	}
	public static void main(String[] args) {
		
		int num=1;
		int de=3;
		
		String resString1=caluculateFractions(num,de);
		
		num=1;
		de=4;
		
		String resString2 = caluculateFractions(num,de);
		
		num=1;
		de=6;
		
        String resString3 = caluculateFractions(num,de);
		
		num=1;
		de=7;
		
		String resString4=caluculateFractions(num,de);
		
		System.out.println(resString1);
		System.out.println(resString2);
		System.out.println(resString3);
		System.out.println(resString4);
	}
}
