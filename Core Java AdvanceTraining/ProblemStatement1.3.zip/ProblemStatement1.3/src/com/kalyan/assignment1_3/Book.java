package com.kalyan.assignment1_3;

public class Book {
	
	String bookTitle;
	double bookPrice;
	
	public Book(String bookTitle,double bookPrice) {
		
		this.bookTitle=bookTitle;
		this.bookPrice=bookPrice;
		
	}
	
	public String getBookTitle() {
		return bookTitle;
		
	}

	public double getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	
	public void display() {
		
		System.out.println("Book Title :"+ this.bookTitle);
		System.out.println("Book price :"+ this.bookPrice);
	}

}
