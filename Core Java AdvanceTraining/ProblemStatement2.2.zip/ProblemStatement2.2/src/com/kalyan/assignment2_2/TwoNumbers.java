package com.kalyan.assignment2_2;

import java.util.Scanner;

public class TwoNumbers{
	public static void main(String[] args) {
		
	

	int i=1,n=19,firstterm=0,secondterm=1;
	Scanner sc = new Scanner(System.in);
	
	
	
	System.out.println("Fibonacci series till  "+n+"terms  :");
	
	while(i<=n) {
		System.out.print(firstterm + ",");
		
		int nextTerm=firstterm+secondterm;
		firstterm=secondterm;
		secondterm=nextTerm;
		i++;
		
	}

}
}

