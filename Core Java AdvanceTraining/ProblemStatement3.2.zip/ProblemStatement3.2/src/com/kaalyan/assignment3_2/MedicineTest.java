package com.kaalyan.assignment3_2;

public class MedicineTest {

	public static void main(String[] args) {
		
		Medicine m[] = new Medicine[5];
		double i= Math.random()*4;
		int j =(int) i;
		System.out.println(j);
		
		switch(j)
		{
		case 1:m[0]=new Medicine();
		m[1]=new Tablet();
		m[0]=displayLabel1();
		m[1]=displayLabel1();
		break;
		
		case 2:m[2]=new Medicine();
		m[3]=new Tablet();
		m[2]=displayLabel1();
		m[3]=displayLabel1();
		break;
		
		case 3:m[4]=new Medicine();
		m[5]=new Tablet();
		m[4]=displayLabel1();
		m[5]=displayLabel1();
		break;
		default:System.out.println("Invalid choice");
		}
	}

	private static Medicine displayLabel1() {
		// TODO Auto-generated method stub
		return null;
	}


	}

