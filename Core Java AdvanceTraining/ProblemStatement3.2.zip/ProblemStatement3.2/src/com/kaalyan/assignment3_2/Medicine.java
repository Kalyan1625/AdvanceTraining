package com.kaalyan.assignment3_2;

public class Medicine {

	public void displayLabel1() {
		System.out.println("Company:GlobexPharma");
		System.out.println("Address:Hyderabad");
	}
}

class Tablet extends Medicine{
	
	public void displayLabel1() {
		
		System.out.println("store in a cool dry place ");
		
	}
}

class Syrup extends Medicine{
	public void displayLabel1() {
		System.out.println("Consumption as directed by thephysician");
	}
}

class Ointment extends Medicine{
	public void dispalyLabel1() {
		System.out.println("for external use only");
	}
}