package com.kalyan.assignment1_4;

import java.util.Scanner;

class Modify {

	int length;
	int width;
	int area;
	int perimeter;
	
	public int getLength() {
		return length;
	
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public void setLength(int length) {
		this.length = length;
	}
	
	public Modify()
	{
		length=1;
		width=1;
	}
	
	void input() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the length of Rectangle: ");
		length = sc.nextInt();
		
		System.out.println("Enter width of Rectangle: ");
		width=sc.nextInt();
	}
	
	void araeRectangle() {
		area = length * width;
		
	}
	
	void perimeterRectangle() {
		perimeter = 2 * (area+width);
		
	}
	
	void display() {
		if(length>0 && length<20) {
			
			System.out.println("Area of Rectangle="+area);
			System.out.println("perimeter of rectangle="+perimeter);
		}
	}
	
	public static void main(String[] args) {
		Modify obj1 = new Modify();
		obj1.input();
		obj1.araeRectangle();
		obj1.perimeterRectangle();
		obj1.display();
		System.out.println("___________________________");
		
		Modify obj2 = new Modify();
		obj2.input();
		obj2.araeRectangle();
		obj2.perimeterRectangle();
		obj2.display();
		System.out.println("___________________________");
		
		Modify obj3 = new Modify();
		obj3.input();
		obj3.araeRectangle();
		obj3.perimeterRectangle();
		obj3.display();
		System.out.println("___________________________");
		
		Modify obj4 = new Modify();
		obj4.input();
		obj4.araeRectangle();
		obj4.perimeterRectangle();
		obj4.display();
		System.out.println("___________________________");
		
		Modify obj5 = new Modify();
		obj5.input();
		obj5.araeRectangle();
		obj5.perimeterRectangle();
		obj5.display();
		System.out.println("___________________________");
		
	}
	
}
