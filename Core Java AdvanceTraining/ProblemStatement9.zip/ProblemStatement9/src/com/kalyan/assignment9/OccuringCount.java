package com.kalyan.assignment9;

import java.util.Scanner;

public class OccuringCount {

	public static void main(String[] args) {
		
		//Scanner sc=new Scanner(System.in);
		int[] arr =new int[] {2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9};
		int[] count=new int[100];
		
		int i,temp=0;
		
		for(i=0;i<arr.length;i++) {
			temp=arr[i];
			count[temp]++;
		}
		for(i=1;i<count.length;i++) {
			if(count[i] >0 && count[i]==1) {
				System.out.printf("%d occurs %d times\n",i,count[i]);
			}
			else
				if(count[i]>=2) {
					System.out.printf("%d occurs %d times\n",i,count[i]);
				}
		}
	}
}
